<?php

namespace app\models;
use app\helpers\DaHelper;
use Yii;

class Stash extends DaHelper
{
    public function find($id = 0)
    {
        $stacks = [];
        $items = [];

        // read everything
        $response = $this->get("/stash/{$id}/contents")->send()->getContent();
        $json = json_decode($response);
        $results = $json->results;
        // var_dump($results);exit;

        foreach ($results as $result) {
            if ($result->size > 1) {
                $stacks[] = $result;
            } else {
                $items[] = $result;
            }
        }

        return compact('stacks', 'items');
    }

    /**
     * Find a single stash item
     * @param  int $id
     * @return json
     */
    public function findOne($id)
    {
        // read everything
        $response = $this->get("/stash/{$id}/contents")->send()->getContent();
        $array = json_decode($response, true);
        // var_dump($array);exit;
        $results = $array['results'];
        return $results[0];
    }
}
