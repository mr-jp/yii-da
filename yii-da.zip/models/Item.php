<?php

namespace app\models;
use app\helpers\DaHelper;
// use yii\httpclient\Client;
use Guzzle\Http\Client;
use yii\httpclient\CurlTransport;
use yii\base\Model;
use Httpful;
use Httpful\Mime;
use Yii;

/**
 * This is the model class for a single stack item
 *
 */
class Item extends Model
{
    public $itemid;
    public $stackid;
    public $title;
    public $description;
    public $tags;
    public $galleryids;
    public $files = [];
    public $artist_comments = "";
    public $original_url;
    public $category;
    public $creation_time;
    public $is_dirty = "false";
    public $mature_content = "true";

    public function setAttributes($values, $safeOnly = true)
    {
        if (isset($values['tags']) && is_array($values['tags'])) {
            $values['tags'] = implode(' ', $values['tags']);
        }
        parent::setAttributes($values, $safeOnly);
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [[
                'itemid',
                'stackid',
                'title',
                'description',
                'files',
                'tags',
                'galleryids',
                'artist_comments',
            ], 'safe'],
        ];
    }

    /**
     * Publish this item
     * @return [type] [description]
     */
    public function publish()
    {
        // save stash details first
        $client = new DaHelper();
        $data = [
            'access_token' => Yii::$app->session->get('access_token'),
            'title' => "{$this->title}",
            'artist_comments' => "test",
            'is_dirty' => "{$this->is_dirty}",
            'itemid ' => "{$this->itemid}",
            'mature_content' => "{$this->mature_content}",
            // 'description' => $this->description,
            // 'tags' => explode(' ', $this->tags)
        ];
        // $request = $client->post("/stash/submit", $data)->send();
        // $client = new Client([
        //     'transport' => 'yii\httpclient\CurlTransport',

        // ]);
        // $url = 'https://www.deviantart.com/api/v1/oauth2/stash/submit';
        // $response = $client->createRequest()->setMethod('POST')->setData($data)->setUrl($url)->send();
        // var_dump($response);exit;

        // $data = json_encode($data);
        // var_dump($data);exit;
        // $response = Httpful\Request::post($url)
                    // ->body($data, Httpful\Mime::FORM)
                    // ->send();
        // var_dump($data);
        // var_dump($response);exit;

        $url = 'https://www.deviantart.com/api/v1/oauth2/stash/submit';
        $client = new Client($url);
        $headers = [
            'Content-Type' => 'application/x-www-form-urlencoded'
        ];
        $request = $client->post($url, $headers, $data);
        // var_dump($data);exit;
        $response = $request->send();
        var_dump($response);exit;

        // publish stash item
        return true;
    }
}
